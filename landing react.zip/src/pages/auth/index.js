export { SignIn, default as SignInDefault } from "@/pages/auth/sign-in";
export { SignUp, default as SignUpDefault } from "@/pages/auth/sign-up";
