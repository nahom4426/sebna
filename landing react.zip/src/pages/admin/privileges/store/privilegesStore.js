// Privileges Store
// This file will contain state management for privileges
