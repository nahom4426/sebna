// Roles API functions
// This file will contain API calls for roles management
