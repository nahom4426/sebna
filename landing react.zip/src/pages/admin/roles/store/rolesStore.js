// Roles Store
// This file will contain state management for roles
