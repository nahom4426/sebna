import React, { useState } from 'react';
import Pagination from '../../../../composables/Pagination';
import RolesStatusRow from '../component/RolesStatusRow';
import RolesDataProvider from '../component/RolesDataProvider';

const Roles = () => {
  const [searchTerm, setSearchTerm] = useState('');

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-800 mb-4">Roles Management</h1>

        <RolesDataProvider search={searchTerm}>
          {({ roles, pending, error, page, perPage, totalElements, totalPages, onPageChange, onPerPageChange, onNext, onPrevious, refresh }) => (
            <>
              <div className="flex gap-4 mb-6">
                <input
                  type="text"
                  placeholder="Search roles..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              {error && (
                <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-600 mb-4">
                  {error}
                </div>
              )}

              <div className="relative space-y-2 w-full min-w-0 bg-white md:space-y-3" style={{ overflow: 'visible', zIndex: 1 }}>
                {/* Desktop Table View */}
                <div className="hidden relative w-full min-w-0 lg:block z-1" style={{ overflow: 'visible' }}>
                  <table
                    className="w-full bg-gradient-to-br from-white via-gray-50 to-gray-100 rounded-lg border border-gray-200 shadow-md backdrop-blur-sm"
                    style={{ overflow: 'visible', transition: 'all 0.3s ease', tableLayout: 'auto', minWidth: '100%' }}
                  >
                    <thead className="backdrop-blur-sm bg-white/70">
                      <tr className="border-b border-gray-200">
                        <th className="px-1.5 sm:px-2 py-1.5 text-[10px] sm:text-xs font-semibold tracking-wide text-left text-gray-700 uppercase border-r border-gray-100">
                          #
                        </th>
                        <th className="px-1.5 sm:px-2 py-1.5 text-[10px] sm:text-xs font-bold text-left uppercase border-r border-gray-100">
                          Name
                        </th>
                        <th className="px-1.5 sm:px-2 py-1.5 text-[10px] sm:text-xs font-bold text-left uppercase border-r border-gray-100">
                          Description
                        </th>
                        <th className="px-1.5 sm:px-2 py-1.5 text-[10px] sm:text-xs font-bold text-left uppercase border-r border-gray-100">
                          Status
                        </th>
                        <th className="px-1.5 sm:px-2 py-1.5 text-[10px] sm:text-xs font-bold text-left uppercase">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {pending ? (
                        <>
                          {[...Array(5)].map((_, i) => (
                            <tr key={`skeleton-${i}`} className="border-b border-gray-200 animate-pulse">
                              <td colSpan="5" className="px-6 py-4">
                                <div className="space-y-2">
                                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                                  <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </>
                      ) : roles.length === 0 ? (
                        <tr>
                          <td colSpan="5" className="px-6 py-8 text-center text-gray-500">
                            No roles found
                          </td>
                        </tr>
                      ) : (
                        <RolesStatusRow
                          rowData={roles}
                          rowKeys={['name', 'description', 'status']}
                          headKeys={['Name', 'Description', 'Status', 'Actions']}
                          page={page}
                          perPage={perPage}
                          onRefresh={refresh}
                        />
                      )}
                    </tbody>
                  </table>
                </div>

                {!pending && roles.length === 0 && (
                  <div className="block lg:hidden text-center py-8">
                    <p className="text-gray-600">No roles found</p>
                  </div>
                )}
              </div>

              {!pending && roles.length > 0 && (
                <Pagination
                  page={page}
                  totalPages={totalPages}
                  totalElements={totalElements}
                  perPage={perPage}
                  rowsCount={roles.length}
                  onPageChange={onPageChange}
                  onPerPageChange={onPerPageChange}
                  onNext={onNext}
                  onPrevious={onPrevious}
                  loading={pending}
                />
              )}
            </>
          )}
        </RolesDataProvider>
      </div>
    </div>
  );
};

export default Roles;
