import ApiService from '@/services/ApiService';

const api = new ApiService(import.meta.env.VITE_API_URI);

// User API endpoints
export function getAllUser(query = {}) {
  const params = new URLSearchParams(query).toString();
  const queryString = params ? `?${params}` : '';
  return api.addAuthenticationHeader().get(`/users/all${queryString}`);
}

export function getUserById(id) {
  return api.addAuthenticationHeader().get(`/users/${id}`);
}

export function createUser(data) {
  return api.addAuthenticationHeader().post('/users/signup', data);
}

export function updateUserById(id, data) {
  return api.addAuthenticationHeader().put(`/users/${id}`, data);
}

export function removeUserById(id) {
  return api.addAuthenticationHeader().delete(`/users/${id}`);
}

export function changeUserStatus(userId, status) {
  return api.addAuthenticationHeader().put(`/users/${userId}/status`, null, {
    params: { status },
  });
}

// Role API endpoints
export function getAllRole(query = {}) {
  const params = new URLSearchParams(query).toString();
  const queryString = params ? `?${params}` : '';
  return api.addAuthenticationHeader().get(`/users/role/all${queryString}`);
}

export function getRoleById(id) {
  return api.addAuthenticationHeader().get(`/users/role/${id}`);
}

export function createRole(data) {
  return api.addAuthenticationHeader().post('/users/role', data);
}

export function updateRoleById(id, data) {
  return api.addAuthenticationHeader().put(`/users/role/${id}`, data);
}

export function removeRoleById(id) {
  return api.addAuthenticationHeader().delete(`/users/role/${id}`);
}

export function changeRoleStatus(roleId, status) {
  return api.addAuthenticationHeader().put(`/users/role/${roleId}/status`, null, {
    params: { status },
  });
}

// Privilege API endpoints
export function getAllPrivilege(query = {}) {
  const params = new URLSearchParams(query).toString();
  const queryString = params ? `?${params}` : '';
  return api.addAuthenticationHeader().get(`/users/privilege/all${queryString}`);
}

export function getPrivilegeById(id) {
  return api.addAuthenticationHeader().get(`/users/privilege/${id}`);
}

export function createPrivilege(data) {
  return api.addAuthenticationHeader().post('/users/privilege', data);
}

export function updatePrivilege(id, data) {
  return api.addAuthenticationHeader().put(`/users/privilege/${id}`, data);
}

export function deletePrivilege(id) {
  return api.addAuthenticationHeader().delete(`/users/privilege/${id}`);
}

export function changePrivilegeStatus(privilegeId, status) {
  return api.addAuthenticationHeader().put(`/users/privilege/${privilegeId}/status`, null, {
    params: { status },
  });
}
